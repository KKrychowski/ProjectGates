﻿#ifndef functions_hpp
#define functions_hpp
#include <vector>
/**
Fukcja wypisująca instrukcję użycia programu w momencie: 
-napotkania błedu
-nie podania przełączników w konsoli
*/
void help();
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool AndGate(bool first, bool second);
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool OrGate(bool first, bool second);
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool NorGate(bool first, bool second);
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool XorGate(bool first, bool second);
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool NandGate(bool first, bool second);
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool NxorGate(bool first, bool second);
/** Funkcja symuluje zachowanie bramki logicznej poprzez porównanie dwóch wartości podanych w parametrach
@param first pierwszy węzeł bramki logicznej
@param second  drugi węzeł bramki logicznej
@return zwracana wartość logiczna po wykonaniu obliczenia
*/
bool NegGate(bool first);
/** funkcja zapisuje dane z vectora do pliku tekstowego w postaci omówionej w sprawozdaniu. Jeżeli wszystko przebiegnie pomyślnie program powiadomi użytkownika komunikatem
@param inputVector jest vectorem z danymi które mają zostać zapisane
*/
void saveFIle(std::vector <std::string> inputVector, std::vector <Node> output, const std::string PATH);
/** funkcja odczytuje dane z pliku tekstowego i zapisuje je do vectora
@param PATH ścieżka pliku tekstowego
@return bramka w postaci: gate = {string GateType,int FirstNodeId,int SecondNodeId,int OutputId} dla bramki NEG postać jest następująca gate = {string GateType,int FirstNodeId,int OutputId}
*/
std::vector <std::string> readFile(const std::string path);
/** funkcja odczytuje surowe dane ze stringa i przetwarza jest pod względem usunięcia znaków spacji oraz ':' które uniemożliwiają prosty odczyt z zapisanego przez nią vectora
@param stringToSplit string który będzie przetwarzany
@return zwraca vector result z przetworzonymi informacjami
*/
std::vector <std::string> splitString(std::string str);
/** Funkcja dokonuje analizy z jaka bramka obecnie jest rozpatrywana
@param gate  obecnie sprawdzana bramka
@param firstInput pierwszy węzeł bramki
@param secondInput drugi węzeł bramki
@return zwracane ID bramki razem z wartością
*/
Node evaluateGate(Gate gate, Node firstInput, Node secondInput);
/** funkcja przeszukuje vector węzłów pod względem szukanego ID węzła
@param nodeId Unikalny numer dla każdego z węzłów
@param nodes vector węzłów z którego będzie szukany
@return jeżeli zostanie odnaleziony, węzeł zostanie zwrócony, w przeciwnym wypadku zostanie zwrócona wartość -1
*/
Node findNode(int nodeId, std::vector <Node> nodes);
/** funkcja pobiera "surowe dane" podane w parametrach i na ich podstawie tworzy bramkę, w przypadku bramki typu NEG zostaje wykonana metoda różniąca się o brak jednego wejścia
@param gateData jest vectorem stringów z informacjami o bramce która ma zostać utworzona
@return bramka w postaci: gate = {string GateType,int FirstNodeId,int SecondNodeId,int OutputId} dla bramki NEG postać jest następująca gate = {string GateType,int FirstNodeId,int OutputId}
*/
Gate assignGate(std::vector <std::string> gateData);
/**
 * funkcja sprawdza czy w argumentach konsoli znajdują się odpowiednie przełączniki.
 @param paths vector z odczytanymi arugmentami funkcji main
 @return zostaje zwracana jedynka w jeżeli operacja się powiedzie, w przeciwnym wypadku -1
 */
int checkArguments(std::vector<std::string> paths);

#endif