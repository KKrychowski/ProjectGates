﻿#ifndef structures_hpp
#define structures_hpp
#include <string>
/**
 węzeł bramki posiadający swoje unikalne id oraz wartość logiczną
 */
struct Node
{
	int id = 0;
	bool value = false;
};
/**
 struktura bramki składającej się ze swojego typu, pierwszego i drugiego węzła wejściowego oraz węzła wyjściowego
 */
struct Gate
{
	std::string gateType;
	int firstInputNodeId = 0;
	int secondInputNodeId = 0;
	int outputNodeId = 0;
};
#endif