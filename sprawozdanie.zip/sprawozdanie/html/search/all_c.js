var searchData=
[
  ['xorgate_0',['XorGate',['../functions_8h.html#aedc7051df81c6d457a22dfe96d944166',1,'functions.h']]]
];
