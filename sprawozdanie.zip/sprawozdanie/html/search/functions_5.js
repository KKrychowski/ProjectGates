var searchData=
[
  ['nandgate_0',['NandGate',['../functions_8h.html#a79f235dc32def1f8f9bbecf8ba7ac2ac',1,'functions.h']]],
  ['neggate_1',['NegGate',['../functions_8h.html#a7e43007b9dc126360ed2669394ffc1d3',1,'functions.h']]],
  ['norgate_2',['NorGate',['../functions_8h.html#a3e90860b89d93c36bc9094b9568417f0',1,'functions.h']]],
  ['nxorgate_3',['NxorGate',['../functions_8h.html#a3efdfe89c8bb70cfa84ad2b4bd2e54fb',1,'functions.h']]]
];
