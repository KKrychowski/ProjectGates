var searchData=
[
  ['gate_0',['Gate',['../structGate.html',1,'']]]
];
