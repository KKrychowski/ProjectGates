var searchData=
[
  ['evaluategate_0',['evaluateGate',['../functions_8h.html#ada77b0ce2a5e595ca9a84d32320d33e3',1,'functions.h']]]
];
