var searchData=
[
  ['value_0',['value',['../structNode.html#aef80e2e69e1b7fdc8fd75ab7c9724941',1,'Node']]]
];
