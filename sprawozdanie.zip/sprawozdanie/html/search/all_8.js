var searchData=
[
  ['orgate_0',['OrGate',['../functions_8h.html#ac836e3a34d7fcae4ecf281b4d61f7563',1,'functions.h']]],
  ['outputnodeid_1',['outputNodeId',['../structGate.html#ab2a961c1a76e1d9dce25712e9f4d528e',1,'Gate']]]
];
