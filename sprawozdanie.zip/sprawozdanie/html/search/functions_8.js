var searchData=
[
  ['savefile_0',['saveFIle',['../functions_8h.html#a86c43ca72398cedb014bd630b9375e13',1,'functions.h']]],
  ['splitstring_1',['splitString',['../functions_8h.html#ac7915255036e528e6a4e6398d69a1c4a',1,'functions.h']]]
];
